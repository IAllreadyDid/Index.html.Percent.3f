/* $Id: lukemftp.h,v 1.20 2000/02/03 09:20:51 lukem Exp $ */

#define	FTP_PRODUCT	"lukemftp"
#define	FTP_VERSION	"1.2"

#include "config.h"

#ifdef __STDC__
# define __P(protos)	protos
# define __STRING(x)	#x
#else
# define __P(protos)	()
# define __STRING(x)	"x"
#endif

#include <sys/types.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>

#include <arpa/ftp.h>
#include <arpa/inet.h>

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <netdb.h>
#include <pwd.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

#ifdef __STDC__
# include <stdarg.h>
# define VA_START(a, f)		va_start(a, f)
# define VA_ARG(v, a, t)	/* no-op */
#else
# include <varargs.h>
# define VA_START(a, f)		va_start(a)
# define VA_ARG(v, a, t)	v = va_arg(a, t)
#endif


#if HAVE_ERR_H
# include <err.h>
#endif


#if ! HAVE_ERR
void	err		__P((int, const char *, ...));
void	errx		__P((int, const char *, ...));
void	warn		__P((const char *, ...));
void	warnx		__P((const char *, ...));
#endif



